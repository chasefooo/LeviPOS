const mysql = require('mysql2/promise');

// Reuse the connection pool between invocations for performance.
let pool;

const getPool = () => {
    if (!pool) {
        pool = mysql.createPool({
            host: process.env.DB_HOST,         // e.g., your RDS endpoint
            user: process.env.DB_USER,         // e.g., admin
            password: process.env.DB_PASSWORD, // provided as an environment variable or secret
            database: process.env.DB_NAME,     // e.g., "production"
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0,
        });
    }
    return pool;
};

exports.handler = async (event) => {
    try {
        const pool = getPool();
        // Example query: fetch the first 10 products
        const [rows] = await pool.query('SELECT * FROM Products LIMIT 10');

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ products: rows }),
        };
    } catch (error) {
        console.error('Database query failed:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to query the database.' }),
        };
    }
};
